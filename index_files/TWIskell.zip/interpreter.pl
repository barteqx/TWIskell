:- compile(lexer).
:- compile(parser).

interpreter(X, Y, R):-
	lexer(Z, X, []), program(T, Z, []), lexer(Tk, Y, []), expression(E, Tk, []), gtrace, preprocessing(T, T1), eval(E, T1, _, R), !.

%globalizing local definitions
preprocessing([(head(variable(X), Y), Expr, Local)|T], [(head(variable(X), Y), Expr1)|T1]):-
	globalize(Local, X, Global), globalize_tree(Expr, Local, X, Expr1),
	preprocessing(T, T2), append(Global, T2, T1), !.
	
preprocessing([X|T], [X|T1]):-
	preprocessing(T, T1).
	
preprocessing([],[]).

globalize(Local, X, Global):-
	globalize(Local, Local, X, Global).

globalize([(head(variable(Id), Args), Expr)|T], Local, X, [(head(variable(NewId), Args), Expr1)|T1]):-
	append(X, "!", X1), append(X1, Id, NewId), globalize_tree(Expr, Local, X, Expr1), globalize(T, Local, X, T1).

globalize([],_,_,[]).

globalize_tree(X, Local, Name, Y):-
	X =.. [A, B, C], globalize_tree(B, Local, Name, B1), globalize_tree(C, Local, Name, C1), Y =.. [A, B1, C1].

globalize_tree(variable(X), Local, Name, variable(NewId)):-
	member((head(variable(X), _), _), Local), append(Name, "!", X1), append(X1, X, NewId).

globalize_tree(X, _, _, X).

%evaluate application
eval(app(H,Y), Env, Args, Result):-
	getExpList(app(H,Y), [H1|L]),
	append(L, Args, Args1),
	eval(H1, Env, Args1, Result).

%evaluate lambdas
eval(lambda(variable(Id), Expr), Env, Args, Result):-
	pattern_matching([variable(Id)], Args, Env, Var, Rest),
	transform(Expr, Var, Expr1, Env),
	eval(Expr1, Env, Rest, Result).
	
%evaluate function
eval(variable(Id), Env, Args, Result):-
	member((head(variable(Id), X), Expression), Env),
	pattern_matching(X, Args, Env, Vars, Rest),
	(eval(Expression, Env, Args, Result);
	transform(Expression, Vars, Expr1, Env),
	eval(Expr1, Env, Rest, Result)).

eval(variable(Id), Env, Args, Result):-
	member((head(variable(Id), X), _), Env),
	length(Args, L1), length(X, L2), L1 < L2, Result = (variable(Id), Args).

%evaluate arithmetics and relations
eval(SExp, Env, Args, constructor(Result, [])):-
	SExp =..[Op, X, Y], member(Op, [=,+,-,*,div,mod,\=, >, <, >=, =<]),
	eval(X, Env, Args, constructor(R1, [])), eval(Y, Env, Args, constructor(R2, [])), 
	Res =.. [Op, R1, R2], (\+ member(Op, [=, >=, =<, >, <, \=]), !, 
	Result is Res; call(Res), !, Result = "True"; Result = "False").

%evaluate costructors	
eval(constructor(X, Y), Env, _, constructor(X, Y1)):- 
	eval_const(Y, Env, Y1).

eval(constructor(X, []), _, _, constructor(X, [])).
	
eval_const([H|T], Env, [H1|T1]):-
	eval(H, Env, _, H1),
	eval_const(T, Env, T1).

eval_const([],_,[]).

%transfrorm from absctract tree to concrete tree	
transform(variable(X), Variables, Y, _):-
	member((variable(X), Y), Variables);
	Y = variable(X).

transform(constructor(X, Y), Variables, constructor(X, Y1), Env):-
	transform_const(Y, Variables, Y1, Env).

transform(X, Variables, Y, Env):-
	X =.. [A, B, C], transform(B, Variables, B1, Env), transform(C, Variables, C1, Env), Y =.. [A, B1, C1].
	
transform_const([H|T], Variables, [H1|T1], Env):-
	transform(H, Variables, H1, Env),
	transform_const(T, Variables, T1, Env).

transform_const([], _, [], _).

%flatten applications	
getExpList(X, L):-
	getExpList(X, L, []).

getExpList(app(X,Y), L2, L):-
	getExpList(Y, L1, L),
	getExpList(X, L2, L1).

getExpList(X, [X|L], L):-
	X \= app(_,_).

%as the name says...
pattern_matching(A, B, Env, L2, Rest):-
	A = [constructor(X, Y)|T], B = [Const|T1],
	eval(Const, Env, [], constructor(X, Y1)),
	pattern_matching(Y, Y1, Env, L, _), pattern_matching(T, T1, Env, L1, Rest), append(L,L1,L2).

pattern_matching([variable(X)|T], [constructor(Y, Z)|T1], Env, [(variable(X), constructor(Y, Z))|Vars], Rest):-
	pattern_matching(T, T1, Env, Vars, Rest).
	
pattern_matching([variable(Y)|T], [variable(X)|T1], Env, [(variable(Y), variable(X))|Vars], Rest):-
	pattern_matching(T, T1, Env, Vars, Rest).
	
pattern_matching([variable(Y)|T], [X|T1], Env, [(variable(Y), Res)|Vars], Rest):-
	eval(X, Env, [], Res),
	pattern_matching(T, T1, Env, Vars, Rest).

pattern_matching([], Rest, _, [], Rest).
